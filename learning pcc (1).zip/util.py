def train_and_visualize_workspace(csv_path):
    from sklearn.metrics import mean_absolute_error
    import numpy as np
    import pandas as pd
    import torch
    import torch.nn as nn
    import matplotlib.pyplot as plt
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from itertools import product

    # === 1. Load dataset ===
    df = pd.read_csv(csv_path)

    # === 2. Extract features and labels ===
    X = df[["actuator1", "actuator2", "actuator3"]].values
    y = df[["X", "Y", "Z"]].values

    # find min and max of each actuator and position Z
    z_min = y[:, 2].min()
    z_max = y[:, 2].max()

    actuator_min = X.min(axis=0)
    actuator_max = X.max(axis=0)

    print("Actuator Min:", actuator_min)
    print("Actuator Max:", actuator_max)
    print("Z Min:", z_min)
    print("Z Max:", z_max)

    # === 3. Normalize ===
    scaler_x = StandardScaler()
    scaler_y = StandardScaler()
    X_scaled = scaler_x.fit_transform(X)
    y_scaled = scaler_y.fit_transform(y)

    # === 4. Convert to torch tensors ===
    X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
    y_tensor = torch.tensor(y_scaled, dtype=torch.float32)

    # === 5. Split and move to device ===
    X_train, X_test, y_train, y_test = train_test_split(
        X_tensor, y_tensor, test_size=0.1, random_state=42
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    X_train, X_test = X_train.to(device), X_test.to(device)
    y_train, y_test = y_train.to(device), y_test.to(device)

    # === 6. Define model ===
    class ActuatorToXYZ(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(3, 64),
                nn.ReLU(),
                nn.Linear(64, 64),
                nn.ReLU(),
                nn.Linear(64, 3),
            )

        def forward(self, x):
            return self.net(x)

    model = ActuatorToXYZ().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = nn.MSELoss()

    # === 7. Train ===
    for epoch in range(200):
        model.train()
        pred = model(X_train)
        loss = loss_fn(pred, y_train)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if epoch % 10 == 0:
            print(f"Epoch {epoch}: Loss = {loss.item():.6f}")

    # === 8. Validation on random 100 test samples ===
    val_indices = np.random.choice(len(X_test), size=100, replace=False)
    X_val_tensor = X_test[val_indices]
    y_val_tensor = y_test[val_indices]

    model.eval()
    with torch.no_grad():
        y_val_pred_scaled = model(X_val_tensor).cpu().numpy()
        y_val_scaled = y_val_tensor.cpu().numpy()

    y_val_pred = scaler_y.inverse_transform(y_val_pred_scaled)
    y_val_true = scaler_y.inverse_transform(y_val_scaled)

    mae = mean_absolute_error(y_val_true, y_val_pred, multioutput="raw_values")
    rmse = np.sqrt(((y_val_true - y_val_pred) ** 2).mean(axis=0))

    print("Validation Set Error (100 Unseen Test Samples):")
    for i, label in enumerate(["X", "Y", "Z"]):
        print(f"{label}  |  MAE: {mae[i]:.4f}  |  RMSE: {rmse[i]:.4f}")

    # === 9. Workspace Visualization ===
    min_length = 62.2
    max_length = 105.6
    samples_per_actuator = 20
    actuator_vals = np.linspace(min_length, max_length, samples_per_actuator)
    grid = np.array(list(product(actuator_vals, repeat=3)))

    X_grid_scaled = scaler_x.transform(grid)
    X_grid_tensor = torch.tensor(X_grid_scaled, dtype=torch.float32).to(device)

    model.eval()
    with torch.no_grad():
        y_grid_pred_scaled = model(X_grid_tensor).cpu().numpy()
    y_grid_pred = scaler_y.inverse_transform(y_grid_pred_scaled)

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection="3d")
    ax.scatter(
        y_grid_pred[:, 0],
        y_grid_pred[:, 1],
        y_grid_pred[:, 2],
        c="deepskyblue",
        s=2,
        alpha=0.6,
    )

    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.set_title("Full Estimated Workspace (Equal Axis Scale)")

    x_vals, y_vals, z_vals = y_grid_pred[:, 0], y_grid_pred[:, 1], y_grid_pred[:, 2]
    max_range = (
        np.array(
            [
                x_vals.max() - x_vals.min(),
                y_vals.max() - y_vals.min(),
                z_vals.max() - z_vals.min(),
            ]
        ).max()
        / 2.0
    )
    mid_x = (x_vals.max() + x_vals.min()) * 0.5
    mid_y = (y_vals.max() + y_vals.min()) * 0.5
    mid_z = (z_vals.max() + z_vals.min()) * 0.5

    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(0, 150)

    ax.grid(True)
    plt.tight_layout()
    plt.show()

    return model, scaler_x, scaler_y


def train_with_residual_model(csv_path):
    import numpy as np
    import pandas as pd
    import torch
    import torch.nn as nn
    import matplotlib.pyplot as plt
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import mean_absolute_error

    from pcc_forward import (
        mpcr_forward,
    )  # Assuming this function is defined in pcc_forward.py

    # ========== Load and Preprocess Data ==========
    df = pd.read_csv(csv_path)
    X_raw = df[["actuator1", "actuator2", "actuator3"]].values
    y_real = df[["X", "Y", "Z"]].values

    # Apply analytical model
    y_model = np.array([mpcr_forward(row) for row in X_raw])
    y_residual = y_real - y_model  # target = true - model

    # Normalize inputs and outputs
    scaler_x = StandardScaler()
    scaler_y = StandardScaler()
    X_scaled = scaler_x.fit_transform(X_raw)
    y_scaled = scaler_y.fit_transform(y_residual)

    # Convert to torch
    X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
    y_tensor = torch.tensor(y_scaled, dtype=torch.float32)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X_tensor, y_tensor, test_size=0.1, random_state=42
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)
    X_train, X_test = X_train.to(device), X_test.to(device)
    y_train, y_test = y_train.to(device), y_test.to(device)

    # ========== Define Network ==========
    class ResidualNet(nn.Module):
        def __init__(self):
            super().__init__()
            # Input layer
            self.input_layer = nn.Linear(3, 64)
            self.input_bn = nn.BatchNorm1d(64)
            self.input_relu = nn.ReLU()

            # Residual block 1
            self.block1_layer1 = nn.Linear(64, 64)
            self.block1_bn1 = nn.BatchNorm1d(64)
            self.block1_relu1 = nn.ReLU()
            self.block1_layer2 = nn.Linear(64, 64)
            self.block1_bn2 = nn.BatchNorm1d(64)
            self.block1_relu2 = nn.ReLU()

            # Residual block 2
            self.block2_layer1 = nn.Linear(64, 64)
            self.block2_bn1 = nn.BatchNorm1d(64)
            self.block2_relu1 = nn.ReLU()
            self.block2_layer2 = nn.Linear(64, 64)
            self.block2_bn2 = nn.BatchNorm1d(64)
            self.block2_relu2 = nn.ReLU()

            # Output layer
            self.output_layer = nn.Linear(64, 3)

            # Optional dropout
            self.dropout = nn.Dropout(0.2)

        def forward(self, x):
            # Input processing
            x = self.input_layer(x)
            x = self.input_bn(x)
            x = self.input_relu(x)

            # Residual block 1
            identity1 = x
            x = self.block1_layer1(x)
            x = self.block1_bn1(x)
            x = self.block1_relu1(x)
            x = self.dropout(x)
            x = self.block1_layer2(x)
            x = self.block1_bn2(x)
            x = x + identity1  # Skip connection
            x = self.block1_relu2(x)

            # Residual block 2
            identity2 = x
            x = self.block2_layer1(x)
            x = self.block2_bn1(x)
            x = self.block2_relu1(x)
            x = self.dropout(x)
            x = self.block2_layer2(x)
            x = self.block2_bn2(x)
            x = x + identity2  # Skip connection
            x = self.block2_relu2(x)

            # Output
            x = self.output_layer(x)

            return x

    model = ResidualNet().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)  # Reduced from 1e-3
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, "min", patience=10, factor=0.5
    )
    loss_fn = nn.MSELoss()

    # ========== Training with Validation Loss ==========

    for epoch in range(400):
        model.train()
        pred = model(X_train)
        train_loss = loss_fn(pred, y_train)

        optimizer.zero_grad()
        train_loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)  # Gradient clipping
        optimizer.step()

        model.eval()
        with torch.no_grad():
            val_pred = model(X_test)
            val_loss = loss_fn(val_pred, y_test)
            scheduler.step(val_loss)  # Update learning rate

        if epoch % 5 == 0:  # More frequent reporting
            print(
                f"Epoch {epoch}: Train Loss = {train_loss.item():.6f} | Val Loss = {val_loss.item():.6f}"
            )

    # ========== Validation Evaluation ==========
    val_indices = np.random.choice(len(X_test), size=100, replace=False)
    X_val_tensor = X_test[val_indices]
    y_val_tensor = y_test[val_indices]

    with torch.no_grad():
        y_residual_pred_scaled = model(X_val_tensor).cpu().numpy()
        y_residual_true_scaled = y_val_tensor.cpu().numpy()

    y_residual_pred = scaler_y.inverse_transform(y_residual_pred_scaled)
    y_residual_true = scaler_y.inverse_transform(y_residual_true_scaled)

    # Reconstruct corrected prediction
    X_val_np = scaler_x.inverse_transform(X_val_tensor.cpu().numpy())
    y_model_val = np.array([mpcr_forward(row) for row in X_val_np])
    y_pred_final = y_model_val + y_residual_pred
    y_true_final = y_model_val + y_residual_true

    mae = mean_absolute_error(y_true_final, y_pred_final, multioutput="raw_values")
    rmse = np.sqrt(((y_true_final - y_pred_final) ** 2).mean(axis=0))
    print("Validation Error (Residual Learning):")
    for i, axis in enumerate(["X", "Y", "Z"]):
        print(f"{axis}  |  MAE: {mae[i]:.4f}  |  RMSE: {rmse[i]:.4f}")

    # ========== Benchmark Comparison ==========
    print("\n--- Benchmark: Sample Predictions vs MoCap ---")
    bench_indices = np.random.choice(len(X_raw), size=10, replace=False)
    for idx in bench_indices:
        actuators = X_raw[idx]
        true_xyz = y_real[idx]
        model_xyz = np.array(mpcr_forward(actuators))

        x_scaled = scaler_x.transform([actuators])
        with torch.no_grad():
            residual_scaled = (
                model(torch.tensor(x_scaled, dtype=torch.float32).to(device))
                .cpu()
                .numpy()
            )
        residual = scaler_y.inverse_transform(residual_scaled)[0]

        pred_xyz = model_xyz + residual
        err_norm = np.linalg.norm(pred_xyz - true_xyz)

        print(f"Actuators: {np.round(actuators, 2)}")
        print(f"  MoCap XYZ   : {np.round(true_xyz, 2)}")
        print(f"  PCC Model   : {np.round(model_xyz, 2)}")
        print(f"  Final Pred. : {np.round(pred_xyz, 2)}")
        print(f"  Residual NN : {np.round(residual, 2)}")
        print(f"  Error Norm  : {err_norm:.2f} mm\n")

    return model, scaler_x, scaler_y, mpcr_forward
